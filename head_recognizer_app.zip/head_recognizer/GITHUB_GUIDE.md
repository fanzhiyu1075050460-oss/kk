# 🚀 GitHub + GitHub Actions 自动构建APK指南

## 整体思路

```
你上传代码到GitHub → GitHub Actions自动构建APK → 你下载APK装手机
```

**你不需要在电脑上安装Flutter！** 全部在云端完成。

---

## 第一步：创建GitHub仓库

1. 打开 https://github.com 登录（没有账号先注册）
2. 点击右上角 `+` → `New repository`
3. 填写仓库名，如 `head-recognizer-app`
4. 选择 **Public**（公开）
5. 点击 `Create repository`

---

## 第二步：上传代码

仓库创建后，你会看到仓库页面。有两种方式上传：

### 方式A：直接网页上传（最简单）

1. 在仓库页面点击 `Add file` → `Upload files`
2. 把你电脑上的 `head_recognizer` 文件夹里的**所有文件**拖进去
3. 点击 `Commit changes`

### 方式B：用Git命令（如果你会用）

```bash
cd head_recognizer
git init
git add .
git commit -m "init app"
git remote add origin https://github.com/你的用户名/head-recognizer-app.git
git push -u origin main
```

---

## 第三步：自动构建APK

代码上传后，**GitHub Actions会自动开始构建**（因为项目里已经有 `.github/workflows/build-apk.yml` 配置）

### 查看构建进度：

1. 进入你的GitHub仓库
2. 点击顶部 `Actions` 标签
3. 你会看到一个名为 `Build APK` 的工作流在运行
4. 等它跑完（通常3-5分钟）

### 下载APK：

1. 构建完成后，点击进入该次构建记录
2. 页面底部有个 `Artifacts` 区域
3. 点击 `app-release-apk` 下载
4. 解压后得到 `app-release.apk`

---

## 第四步：安装到手机

1. 把 `app-release.apk` 传到安卓手机（微信/QQ/数据线都行）
2. 手机点击安装
3. 如果提示"不允许安装" → 去设置里允许"安装未知来源应用"

---

## 🔄 之后修改代码怎么办？

比如你想改识别逻辑、改界面：
1. 在GitHub网页上直接编辑文件，或本地改完重新上传
2. 每次 `push` 代码 → GitHub Actions自动重新构建
3. 去 `Actions` 页面下载最新的APK

---

## ❓ 常见问题

**Q: Actions页面显示失败（红色叉号）怎么办？**
→ 点进去看日志，把报错信息发出来，我帮你排查。

**Q: 构建要等多久？**
→ 通常3-5分钟，首次可能稍慢。

**Q: APK文件在哪？**
→ `Actions` → 点进最新的构建 → 页面底部的 `Artifacts` → 下载。

**Q: 免费吗？**
→ GitHub Actions对个人免费，每月有额度限制，做这个完全够用。

---

## 📁 完整项目结构

```
head_recognizer/
├── .github/
│   └── workflows/
│       └── build-apk.yml        ← 自动构建配置（关键！）
├── android/                      ← 安卓原生配置
├── lib/
│   ├── main.dart                 ← App入口
│   ├── services/
│   │   ├── ocr_service.dart      ← OCR识别
│   │   ├── parse_rule.dart       ← 提取X头关键词
│   │   └── db_helper.dart        ← 数据库
│   └── pages/
│       ├── scan_page.dart        ← 识别页面
│       └── history_page.dart     ← 记录页面
├── pubspec.yaml                   ← 依赖配置
└── README.md
```

---

就这么简单！上传 → 等3分钟 → 下载APK → 装手机 ✅
