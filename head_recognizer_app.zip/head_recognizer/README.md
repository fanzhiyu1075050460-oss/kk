# 头数关键词识别记录 App

## 功能说明

输入期数 → 拍照/选图 → 自动识别图片中的「X头」关键词（0头、1头、2头、3头、4头）→ 本地记录管理。

## 技术栈

- **Flutter** — 跨平台UI
- **Google ML Kit** — 端侧OCR（离线免费）
- **sqflite** — 本地数据库
- **image_picker** — 拍照/选图

## 项目结构

```
lib/
├── main.dart              # 入口 + 底部导航
├── services/
│   ├── ocr_service.dart   # OCR识别（ML Kit）
│   ├── parse_rule.dart    # 解析规则：提取X头关键词
│   └── db_helper.dart     # SQLite数据库操作
└── pages/
    ├── scan_page.dart     # 首页：输入期数+选图识别
    └── history_page.dart  # 记录页：按期数筛选查看
```

## 使用步骤

### 1. 环境准备

确保已安装 Flutter SDK（3.0+）：

```bash
flutter --version
```

### 2. 获取依赖

```bash
flutter pub get
```

### 3. 运行

```bash
# 连接真机或模拟器后
flutter run
```

> ⚠️ OCR依赖相机，建议使用**真机**调试。

### 4. 使用流程

1. 首页输入**期数**（如 `254`）
2. 点击「拍照识别」或「相册识别」
3. App自动OCR → 提取该期数下的「0头~4头」关键词
4. 结果自动存入本地数据库
5. 切换到「记录」页查看/筛选历史

## 扩展说明

如需识别更多头数（如5头~9头），编辑 `lib/services/parse_rule.dart`：

```dart
static const List<String> validHeads = [
  '0头', '1头', '2头', '3头', '4头',
  '5头', '6头', '7头', '8头', '9头',  // 取消注释即可
];
```

## 权限说明

- **相机**：拍照识别
- **相册**：从相册选择图片
- **存储**：保存识别记录到本地数据库

所有数据仅存储在设备本地，不上传任何服务器。
