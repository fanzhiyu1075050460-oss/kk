import 'package:flutter/material.dart';
import '../services/db_helper.dart';

/// 历史记录页：按指定期数筛选查看已保存的记录
class HistoryPage extends StatefulWidget {
  const HistoryPage({super.key});

  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  final TextEditingController _filterController = TextEditingController();
  List<Map<String, dynamic>> _records = [];
  List<String> _allPeriods = [];

  @override
  void initState() {
    super.initState();
    _loadAll();
  }

  @override
  void dispose() {
    _filterController.dispose();
    super.dispose();
  }

  /// 加载全部记录 + 所有期数
  Future<void> _loadAll() async {
    final all = await DbHelper.queryAll();
    final periods = await DbHelper.getAllPeriods();
    setState(() {
      _records = all;
      _allPeriods = periods;
    });
  }

  /// 按期数筛选
  Future<void> _filter(String period) async {
    if (period.isEmpty) {
      await _loadAll();
      return;
    }
    final rows = await DbHelper.queryByPeriod(period);
    setState(() => _records = rows);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('识别记录'),
        actions: [
          IconButton(
            onPressed: () async {
              await DbHelper.clearAll();
              await _loadAll();
            },
            icon: const Icon(Icons.delete_sweep),
            tooltip: '清空全部',
          ),
        ],
      ),
      body: Column(
        children: [
          // 筛选栏
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _filterController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: '按期数筛选',
                      hintText: '如 254',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                    onChanged: _filter,
                  ),
                ),
                const SizedBox(width: 8),
                // 快捷选择已有期数
                if (_allPeriods.isNotEmpty)
                  DropdownButton<String>(
                    hint: const Text('选择'),
                    items: _allPeriods.map((p) => DropdownMenuItem(
                          value: p,
                          child: Text('${p}期'),
                        )).toList(),
                    onChanged: (p) {
                      _filterController.text = p ?? '';
                      _filter(p ?? '');
                    },
                  ),
              ],
            ),
          ),

          // 记录列表
          Expanded(
            child: _records.isEmpty
                ? const Center(child: Text('暂无记录'))
                : ListView.builder(
                    itemCount: _records.length,
                    itemBuilder: (_, i) {
                      final r = _records[i];
                      return Card(
                        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        child: ListTile(
                          leading: const Icon(Icons.label, color: Colors.blue),
                          title: Text('${r['period']}期 — ${r['head']}'),
                          subtitle: Text(r['raw_line'] ?? ''),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete, size: 20),
                            onPressed: () async {
                              await DbHelper.delete(r['id']);
                              await _loadAll();
                            },
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
