import 'package:flutter/material.dart';
import '../services/ocr_service.dart';
import '../services/parse_rule.dart';
import '../services/db_helper.dart';

/// 首页：输入期数 + 选图 → 识别 → 显示并保存结果
class ScanPage extends StatefulWidget {
  const ScanPage({super.key});

  @override
  State<ScanPage> createState() => _ScanPageState();
}

class _ScanPageState extends State<ScanPage> {
  final TextEditingController _periodController = TextEditingController();
  bool _isProcessing = false;
  String _ocrRawText = '';
  List<HeadRecord> _results = [];

  @override
  void dispose() {
    _periodController.dispose();
    super.dispose();
  }

  /// 主流程：选图 → OCR → 解析 → 存库
  Future<void> _process(ImageSource source) async {
    if (_periodController.text.trim().isEmpty) {
      _showSnack('请先输入期数');
      return;
    }

    final targetPeriod = _periodController.text.trim();

    setState(() => _isProcessing = true);

    try {
      // 1. OCR识别
      final text = await OcrService.recognizeFromImage(source);
      if (text.isEmpty) {
        _showSnack('未识别到文字，请重新选择图片');
        return;
      }

      // 2. 解析「X头」关键词（只收集指定期数）
      final records = ParseRule.parse(text, targetPeriod: targetPeriod);

      // 3. 存入数据库
      if (records.isNotEmpty) {
        await DbHelper.insertRecords(records);
      }

      // 4. 展示
      setState(() {
        _ocrRawText = text;
        _results = records;
      });

      _showSnack(
        records.isEmpty ? '未在图中找到「X头」关键词' : '已识别并保存 ${records.length} 条',
      );
    } catch (e) {
      _showSnack('识别失败：$e');
    } finally {
      setState(() => _isProcessing = false);
    }
  }

  void _showSnack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('头数关键词识别')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // 期数输入
            TextField(
              controller: _periodController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: '输入期数',
                hintText: '例如：254',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.tag),
              ),
            ),
            const SizedBox(height: 16),

            // 选择图片按钮
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _isProcessing ? null : () => _process(ImageSource.camera),
                    icon: const Icon(Icons.camera_alt),
                    label: const Text('拍照识别'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _isProcessing ? null : () => _process(ImageSource.gallery),
                    icon: const Icon(Icons.photo_library),
                    label: const Text('相册识别'),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 24),

            // 加载状态
            if (_isProcessing) const Center(child: CircularProgressIndicator()),

            // 识别结果
            if (!_isProcessing && _results.isNotEmpty) ...[
              const Text('识别结果', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              const SizedBox(height: 8),
              ..._results.map((r) => Card(
                    child: ListTile(
                      leading: const Icon(Icons.check_circle, color: Colors.green),
                      title: Text('${r.period}期 — ${r.head}'),
                      subtitle: Text(r.rawLine),
                    ),
                  )),
            ],

            // OCR原始文本（可折叠调试）
            if (!_isProcessing && _ocrRawText.isNotEmpty) ...[
              const SizedBox(height: 24),
              const Text('OCR原始文本', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  _ocrRawText,
                  style: const TextStyle(fontSize: 12, color: Colors.black54),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
