/// 解析规则：从OCR文本中提取「X头」关键词
///
/// 支持识别：0头、1头、2头、3头、4头（以及可能的5-9头）
/// 兼容写法：如 "0头" "0头数" "【0头】" "[0头]" "0-head" 等

class HeadRecord {
  final String period;       // 期数，如 "254"
  final String head;          // 头数关键词，如 "0头"
  final String rawLine;       // 命中的原始文本行，便于追溯

  const HeadRecord({
    required this.period,
    required this.head,
    required this.rawLine,
  });

  Map<String, dynamic> toMap() => {
        'period': period,
        'head': head,
        'raw_line': rawLine,
        'created_at': DateTime.now().toIso8601String(),
      };

  @override
  String toString() => '$period期 - $head';
}

class ParseRule {
  // 所有要识别的「头」关键词，可按需扩展
  static const List<String> validHeads = [
    '0头', '1头', '2头', '3头', '4头',
    // 如需扩展：'5头','6头','7头','8头','9头',
  ];

  /// 从OCR整段文本中，按指定期数提取「X头」关键词
  ///
  /// [ocrText] OCR识别出的全部文字
  /// [targetPeriod] 指定期数，如 "254"。为null时收集所有期数
  /// [contextWindow] 关键词前后搜索「期数」的行数窗口
  static List<HeadRecord> parse(String ocrText, {String? targetPeriod}) {
    final lines = ocrText
        .split(RegExp(r'[\n\r]+'))
        .map((l) => l.trim())
        .where((l) => l.isNotEmpty)
        .toList();

    final results = <HeadRecord>[];

    for (int i = 0; i < lines.length; i++) {
      final line = lines[i];

      // 1. 找出这一行的期数（如果有）
      final periodInLine = _extractPeriod(line);

      // 2. 检查这一行是否包含「X头」关键词
      final headsInLine = _extractHeads(line);

      if (headsInLine.isEmpty) continue;

      // 3. 确定该行所属的期数
      String? period;
      if (periodInLine != null) {
        period = periodInLine;
      } else {
        // 若本行没有期数，向前搜索最近一行的期数（上下文关联）
        period = _findNearestPeriod(lines, i);
      }

      // 4. 过滤指定期数
      if (targetPeriod != null && period != targetPeriod) continue;

      for (final head in headsInLine) {
        results.add(HeadRecord(
          period: period ?? '未知',
          head: head,
          rawLine: line,
        ));
      }
    }

    // 去重：同 期数+头 只保留一条
    return _distinct(results);
  }

  /// 从文本中提取期数，如 "254期" -> "254"
  static String? _extractPeriod(String text) {
    final m = RegExp(r'(\d{2,4})\s*期').firstMatch(text);
    return m?.group(1);
  }

  /// 从文本中提取所有「X头」关键词
  static List<String> _extractHeads(String text) {
    final List<String> found = [];
    for (final h in validHeads) {
      // 匹配：0头 / 0头数 / 【0头】 / [0头] / 0-head 等写法
      final pattern = RegExp(
        '${h[0]}\\s*[-－]?\\s*头',
        caseSensitive: false,
      );
      if (pattern.hasMatch(text)) {
        found.add(h);
      }
    }
    return found;
  }

  /// 向上查找最近的期数（用于处理「期数+多行内容」的排版）
  static String? _findNearestPeriod(List<String> lines, int currentIndex) {
    for (int j = currentIndex - 1; j >= 0 && j >= currentIndex - 5; j--) {
      final p = _extractPeriod(lines[j]);
      if (p != null) return p;
    }
    return null;
  }

  /// 按 (period, head) 去重
  static List<HeadRecord> _distinct(List<HeadRecord> list) {
    final seen = <String>{};
    final out = <HeadRecord>[];
    for (final r in list) {
      final key = '${r.period}_${r.head}';
      if (!seen.contains(key)) {
        seen.add(key);
        out.add(r);
      }
    }
    return out;
  }
}
