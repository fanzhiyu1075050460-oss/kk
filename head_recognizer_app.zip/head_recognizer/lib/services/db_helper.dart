import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../services/parse_rule.dart';

/// 本地数据库助手：存储/查询识别记录
class DbHelper {
  static const _dbName = 'head_records.db';
  static const _dbVersion = 1;
  static const table = 'records';

  static Database? _db;

  static Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _initDb();
    return _db!;
  }

  static Future<Database> _initDb() async {
    final path = join(await getDatabasesPath(), _dbName);
    return openDatabase(
      path,
      version: _dbVersion,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE $table (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            period TEXT NOT NULL,
            head TEXT NOT NULL,
            raw_line TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
          )
        ''');
        // 索引：按期数查询更快
        await db.execute('CREATE INDEX idx_period ON $table(period)');
      },
    );
  }

  /// 批量插入记录（同 period+head 自动替换去重）
  static Future<void> insertRecords(List<HeadRecord> records) async {
    final db = await database;
    final batch = db.batch();
    for (final r in records) {
      batch.insert(
        table,
        r.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    }
    await batch.commit(noResult: true);
  }

  /// 查询指定期数的所有记录
  static Future<List<Map<String, dynamic>>> queryByPeriod(String period) async {
    final db = await database;
    return db.query(
      table,
      where: 'period = ?',
      whereArgs: [period],
      orderBy: 'created_at DESC',
    );
  }

  /// 查询全部记录（按时间倒序）
  static Future<List<Map<String, dynamic>>> queryAll() async {
    final db = await database;
    return db.query(table, orderBy: 'created_at DESC');
  }

  /// 获取所有已记录的期数（去重）
  static Future<List<String>> getAllPeriods() async {
    final db = await database;
    final rows = await db.rawQuery(
      'SELECT DISTINCT period FROM $table ORDER BY created_at DESC',
    );
    return rows.map((r) => r['period'] as String).toList();
  }

  /// 删除某条记录
  static Future<void> delete(int id) async {
    final db = await database;
    await db.delete(table, where: 'id = ?', whereArgs: [id]);
  }

  /// 清空全部
  static Future<void> clearAll() async {
    final db = await database;
    await db.delete(table);
  }
}
