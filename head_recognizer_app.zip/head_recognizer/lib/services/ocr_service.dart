import 'dart:io';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:image_picker/image_picker.dart';

/// OCR 识别服务：把图片中的文字提取出来
class OcrService {
  static final TextRecognizer _recognizer = TextRecognizer();

  /// 从相册/相机获取图片并识别文字
  static Future<String> recognizeFromImage(ImageSource source) async {
    final picker = ImagePicker();
    final XFile? file = await picker.pickImage(
      source: source,
      maxWidth: 1200,
      imageQuality: 90,
    );
    if (file == null) return '';

    final input = InputImage.fromFilePath(file.path);
    final recognized = await _recognizer.processImage(input);
    return recognized.text;
  }

  /// 识别后自动关闭释放（在页面中调用）
  static void dispose() {
    _recognizer.close();
  }
}
